# Data README

## Folder Structure

The folder contains EMOS multi-agent system discussion history with **different formats** of robot resumes. Each folder represent a setting of format of robot resume. Each format contains 10 folders titled with the episode ids representing the experiments on the corresponding episodes. Each episode directory contains JSON files that log the agent input prompts with robot resumes and chat history. Below is the structure of the workspace:

```
json/
  6/
    agent_0_action_history.json
    agent_0_group_chat_history.json
    agent_1_action_history.json
    agent_1_group_chat_history.json
    leader_group_chat_history.json
    token_usage.json
  ...
language/
  ...
markdown/
  ...
xml/
  ...
```

We present our experimental results on success rate of each format setting below:

| Episode | JSON | Natural Language | Markdown | XML  |
| ------- | ---- | ---------------- | -------- | ---- |
| 6       | 0    | 0                | 0        | 0    |
| 7       | 1    | 1                | 1        | 1    |
| 91      | 1    | 1                | 1        | 1    |
| 112     | 1    | 0                | 1        | 1    |
| 146     | 1    | 0                | 1        | 1    |
| 180     | 0    | 0                | 0        | 0    |
| 182     | 1    | 0                | 0        | 1    |
| 262     | 0    | 0                | 0        | 0    |
| 310     | 1    | 1                | 0        | 0    |
| 327     | 1    | 0                | 1        | 1    |
| Average | 0.7  | 0.3              | 0.5      | 0.6  |
