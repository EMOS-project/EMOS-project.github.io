# Data README

## Folder Structure

The folder contains 10 EMOS multi-agent system discussion history with adding battery life to robot resumes, each representing an experiment on an episode. Each episode directory contains JSON files that log the agent input prompts with robot resumes and chat history. Below is the structure of the workspace:

```
21/
    agent_0_action_history.json
    agent_0_group_chat_history.json
    agent_1_action_history.json
    agent_1_group_chat_history.json
    leader_group_chat_history.json
    token_usage.json
...
```

You can search for `battery life` or `battery_life` in the chat history to check how the new capability is passed and integrated into the conversation.