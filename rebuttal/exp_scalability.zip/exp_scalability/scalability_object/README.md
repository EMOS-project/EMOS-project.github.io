# Data README

## Folder Structure

The folder contains EMOS multi-agent system discussion history with **different task complexity**. Each folder represents a setting of task complexity with the setting of different object numbers to rearrange. We name the folder as `object_[number]` Each task setting contains 10 folders titled with the episode ids representing the experiments on the corresponding episodes. Each episode directory contains JSON files that log the agent input prompts with robot resumes and chat history. Below is the structure of the workspace:

```
object_1/
  0/
    agent_0_action_history.json
    agent_0_group_chat_history.json
    agent_1_action_history.json
    agent_1_group_chat_history.json
    leader_group_chat_history.json
    token_usage.json
  ...
object_2/
  ...
object_3/
  ...
object_5/
  ...
```

We present our experimental results on the success rate of each task complexity setting below:

| Number of Objects | Success Rate (%) | Token Usage |
| ----------------- | ---------------- | ----------- |
| 1                 | 90%              | 25778       |
| 2                 | 80%              | 50005       |
| 3                 | 80%              | 87668       |
| 5                 | 70%              | 197485      |