# Data README

## Folder Structure

The folder contains EMOS multi-agent system discussion history with **different robot numbers** in the folder named `scalability_robot` and **different task complexities** in the folder named `scalability_object`. For the file structures and detailed experimental results, please refer to the corresponding folders.

## Experimental Results

**Table 1: Scalability with Robot Number**

| Number of Robots | Success Rate (%) | Token Usage |
| ---------------- | ---------------- | ----------- |
| 2                | 80%              | 48779       |
| 4                | 60%              | 73202       |
| 6                | 70%              | 93252       |
| 10               | 50%              | 151952      |

**Table 2: Scalability with Task Complexity**

| Number of Objects | Success Rate (%) | Token Usage |
| ----------------- | ---------------- | ----------- |
| 1                 | 90%              | 25778       |
| 2                 | 80%              | 50005       |
| 3                 | 80%              | 87668       |
| 5                 | 70%              | 197485      |