# Data README

## Folder Structure

The folder contains EMOS multi-agent system discussion history with **different robot numbers**. Each folder represents the setting of different robot numbers. We name the folder as `robot_[number]`. Each task setting contains 10 folders titled with the episode ids representing the experiments on the corresponding episodes. Each episode directory contains JSON files that log the agent input prompts with robot resumes and chat history. Below is the structure of the workspace:

```
robot_2/
  0/
    agent_0_action_history.json
    agent_0_group_chat_history.json
    agent_1_action_history.json
    agent_1_group_chat_history.json
    leader_group_chat_history.json
    token_usage.json
  ...
robot_4/
  ...
robot_6/
  ...
robot_10/
  ...
```

We present our experimental results on the success rate of each robot number setting below:

| Number of Robots | Success Rate (%) | Token Usage |
| ---------------- | ---------------- | ----------- |
| 2                | 80%              | 48779       |
| 4                | 60%              | 73202       |
| 6                | 70%              | 93252       |
| 10               | 50%              | 151952      |