# Data README

## Folder Structure

The folder contains EMOS multi-agent system robot resumes with **different formats** in our experiments on the impact of robot resume format. We name the folder as `robot_resume_[format]`. Each folder contains the robot resumes of different types of robots. Below is the structure of the workspace:

```
robot_resume_battery/
  DJIDrone_default.json
  FetchRobot_arm_only.json
  ...
robot_resume_json/
  ...
robot_resume_language/
  ...
robot_resume_markdown/
  ...
robot_resume_xml/
  ...
```

